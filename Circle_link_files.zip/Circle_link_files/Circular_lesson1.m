% Vertigo
%
% Jon Sowman 2017
% jon+vertigo@jonsowman.com
% Luke Gonsalves 2017
% Get raw data
[csvfile, csvpath] = uigetfile('*.csv');
csvdata = csvread([csvpath csvfile]);
% for greater gps resolution use command below
%csvdata = dlmread([csvpath csvfile]);

% Split into GPS and IMU data
gpsidx = find(csvdata(:,2) == 1);
imuidx = find(csvdata(:,2) == 2);
quatidx = find(csvdata(:,2) == 3);
gpsdata = csvdata(gpsidx, :);
imudata = csvdata(imuidx, :);
quatdata = csvdata(quatidx, :);

% Adjust all times
gpsdata(:,1) = (gpsdata(:,1) - gpsdata(1,1)) / 1000;
imudata(:,1) = (imudata(:,1) - imudata(1,1)) / 1000;
quatdata(:,1) = (quatdata(:,1) - quatdata(1,1)) / 1000;

% Do quaternion->Euler conversion
euldata = zeros(length(quatdata), 3);
for i = 1:length(quatdata)
    euldata = vtg_quat2eul(quatdata);

end
%euldata = vtg_quat2eul(quatdata);


t = imudata(:,1); %Time Variable





accel_ned = zeros(length(imudata), 3);
gyro_ned  = zeros(length(imudata), 3);

for i = 1:length(imudata)
    quat_int = interp1(quatdata(:,1), quatdata(:, 3:6), imudata(i,1));
    a = [0 imudata(i, 3:5)];
    g = [0 imudata(i, 6:8)];
    aa = quatmultiply(quatmultiply(quat_int, a), quatconj(quat_int));
    accel_ned(i, :) = aa(2:4);
    gg= quatmultiply(quatmultiply(quat_int, g), quatconj(quat_int));
    gyro_ned(i, :) = gg(2:4);
end

gyro_ned = [imudata(:,1) gyro_ned];


subplot(2,1,1);
plot(imudata(:,1), imudata(:, 3:5));
xlabel('Time (s)');
ylabel('Raw accel (g)');
legend('x', 'y', 'z');

subplot(2,1,2);
plot(imudata(:,1), accel_ned);
xlabel('Time (s)');
ylabel('NED accel (g)');
legend('N', 'E', 'D');


figure
subplot(2,1,1);
plot(imudata(:,1), imudata(:, 6:8));
xlabel('Time (s)');
ylabel('Raw gyro (deg/s)');
legend('x', 'y', 'z');

subplot(2,1,2);
plot(imudata(:,1), gyro_ned(:,2:4));
xlabel('Time (s)');
ylabel('NED gyro (deg/s)');
legend('N', 'E', 'D');
%calculating angles


Phi_radians = atan2(2.*((quatdata(:,3).*quatdata(:,6))+(quatdata(:,4).*quatdata(:,5))),1 - 2.*(((quatdata(:,3).^2)+(quatdata(:,4).^2))))
Phi = (Phi_radians)*180./pi
Theta_radians = asin (2.*(quatdata(:,4).*quatdata(:,6) -   quatdata(:,3).*quatdata(:,5)));
Theta = (Theta_radians).*180./pi
Psi_radians = atan2(2.*((quatdata(:,5).*quatdata(:,6))+(quatdata(:,3).*quatdata(:,4))),1 - 2.*(((quatdata(:,4).^2)+(quatdata(:,5).^2))))
Psi = -(Psi_radians).*180./pi
figure;
plot (quatdata(:,1), Phi, quatdata(:,1), Theta, quatdata(:,1), Psi);

xlabel('Time (s)');
ylabel('Rotation/degrees ');
legend('yaw','Pitch', 'Roll');


gpsdata = evalin('base', 'gpsdata');
imudata = evalin('base', 'imudata');
accel_ned = evalin('base', 'accel_ned');

% Convert GPS data into metres from starting position
gpstime = gpsdata(:,1);
[east, north] = ll2utm(gpsdata(:,4), gpsdata(:,3));
dalt = -(gpsdata(:,5) - gpsdata(1,5)); % Down is positive
deast = east - east(1);
dnorth = north - north(1);

% Interpolate GPS data onto the IMU data
time = imudata(:,1);
deast = interp1(gpstime, deast, time, 'pchip', 'extrap');
dnorth = interp1(gpstime, dnorth, time, 'pchip', 'extrap');
dalt = interp1(gpstime, dalt, time, 'pchip', 'extrap');

% Run Kalman filter
Nstep = length(time);

% State vector: [s_n, s_e, s_d, v_n, v_e, v_d, a_n, a_e, a_d]
x = zeros(9, 1);
P = 1e-3 * eye(9);

dt = time(2) - time(1); % This is still a really bad plan

% Process noise
Q = diag([1e-9 1e-9 1e-9 1e-9 1e-9 1e-9 1e-3 1e-3 1e-3]);
% Measurement noise
gps_var = 1e-9;
imu_var = 1e-0;
R = diag([gps_var gps_var gps_var*10 imu_var imu_var imu_var]);

% Discrete time model
% s_n(k+1) = s_n(k) + v_n(k) * dt
% v_n(k+1) = v_n(k) + a_n(k) * dt
% a_n(k+1) = a_n(k)
F = [1 0 0 dt 0  0  0  0  0; ...
     0 1 0 0  dt 0  0  0  0; ...
     0 0 1 0  0  dt 0  0  0; ...
     0 0 0 1  0  0  dt 0  0; ...
     0 0 0 0  1  0  0  dt 0; ...
     0 0 0 0  0  1  0  0  dt; ...
     0 0 0 0  0  0  1  0  0; ...
     0 0 0 0  0  0  0  1  0; ...
     0 0 0 0  0  0  0  0  1];
 
H = [1 0 0 0 0 0 0 0 0; ...
     0 1 0 0 0 0 0 0 0; ...
     0 0 1 0 0 0 0 0 0; ...
     0 0 0 0 0 0 1 0 0; ...
     0 0 0 0 0 0 0 1 0; ...
     0 0 0 0 0 0 0 0 1];

%  Now in vtg_load_data_and_transform
% % Remove gravity from NED accel, leaving linear accels in NED frame
% accel_ned(:,3) = accel_ned(:,3) - 1;
% accel_ned = accel_ned .* 9.81;

% Sensors
sensors = @(i) [dnorth(i);
                deast(i);
                dalt(i);
                accel_ned(i, 1:3)'];
                
kal_x_stor = zeros(9, Nstep);

h = waitbar(0, 'Running Kalman filter...');
for i = 1:Nstep
    % Predict
    xp = F * x; % no inputs
    Pp = F * P * F' + Q;
    
    % Update
    y = sensors(i) - H * x;
    S = H * P * H' + R;
    K = Pp * H' * inv(S);
    x = xp + K * y;
    P = (eye(9) - K * H) * Pp;
    
    % Store
    kal_x_stor(:, i) = x;
    
    % Waitbar
    if mod(i/Nstep, 0.1) == 0
        waitbar(i/Nstep, h);
    end
end
close(h);



%end % function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Yaw angle
Phi_radians = -atan2(2.*((quatdata(:,3).*quatdata(:,6))+(quatdata(:,4).*quatdata(:,5))),1 - 2.*(((quatdata(:,3).^2)+(quatdata(:,4).^2))));
Phi = (Phi_radians)*180./pi;
Yaw = Phi;
%roll angle
Theta_radians = asin (2.*(quatdata(:,4).*quatdata(:,6) -   quatdata(:,3).*quatdata(:,5)));
Theta = (Theta_radians).*180./pi;
Roll = Theta;
% Pitch angle
Psi_radians = atan2(2.*((quatdata(:,5).*quatdata(:,6))+(quatdata(:,3).*quatdata(:,4))),1 - 2.*(((quatdata(:,4).^2)+(quatdata(:,5).^2))));
Psi = (Psi_radians).*180./pi;
Pitch = Psi;
quiver_length = 3;
[rollx,rolly] = pol2cart(((Theta_radians)),quiver_length);
[pitchx,pitchy] = pol2cart(((Psi_radians+pi)),quiver_length);
[yawx,yawy] = pol2cart((Phi_radians),quiver_length);

%Cartesian vectors for roll, pitch and yaw with time
roll_pitch_yaw_t = [rollx rolly pitchx pitchy yawx yawy quatdata(:,1)];
Angles = [Roll Pitch Yaw quatdata(:,1)];

prompt = 'What time do you wish to start analysis from? ';
window_start = input(prompt);
prompt = 'What time do you wish to end the analysis? ';
window_end = input(prompt);

%Total time samples
total_time = [imudata(:,1) ; gpstime];
%sort in time chronological order
stotal_time = sort(total_time);






% Extract the bit of data we want to look at
tstartidx = find(imudata(:,1) > window_start, 1);
tendidx = find(imudata(:,1) > window_end, 1);
Time_window = time(tstartidx:tendidx,1);

% tstartquat = find(quatdata(:,1) > window_start, 1);
% tendquat = find(quatdata(:,1) > window_end, 1);
% Time_windowQUAT = time(tstartquat:tendquat,1);


kal_x_storT =kal_x_stor';
% smooth_north_position = smooth (kal_x_storT(tstartidx:tendidx,1));
smooth_north_position = movmean(kal_x_storT(tstartidx:tendidx,1),50);
% smooth_east_position = smooth(kal_x_storT(tstartidx:tendidx,2));
smooth_east_position = movmean(kal_x_storT(tstartidx:tendidx,2),50);
smooth_down_position = - movmean(kal_x_storT(tstartidx:tendidx,3),50);
north_vel_elements = movmean (kal_x_storT(tstartidx:tendidx,4),50);
east_vel_elements = movmean (kal_x_storT(tstartidx:tendidx,5),50);
down_vel_elements = movmean (kal_x_storT(tstartidx:tendidx,6),50);
north_accel_elements = movmean(kal_x_storT(tstartidx:tendidx,7),50);
east_accel_elements = smooth(kal_x_storT(tstartidx:tendidx,8));
down_accel_elements = smooth (kal_x_storT(tstartidx:tendidx,9));
roll_pitch_yaw_twindow = roll_pitch_yaw_t (tstartidx:tendidx,:);
Angles_window = Angles(tstartidx:tendidx,:);
% quat_data = quatdata(tstartidx:tendidx, :);
% euldata_window = euldata (tstartidx:tendidx, :);

NEDT = [smooth_north_position smooth_east_position smooth_down_position Time_window];

% Find the spot velocities and accelerations as taken from the kalman position
VelN = ((movmean (diff(NEDT(:,1))./0.01,10)));
VelE = ((movmean (diff(NEDT(:,2))./0.01,10)));
VelD = - ((movmean (diff(NEDT(:,3))./0.01,10)));
accelN = (movmean (diff(VelN)./0.01,10));
accelE = (movmean (diff(VelE)./0.01,10));
accelD = (movmean (diff(VelD)./0.01,10));

NEDT_vels = [VelN VelE VelD Time_window(1:end-1,:)];

NEDT_accels = [accelN accelE accelD Time_window(1:end-2,:)];

%calculate the magnitude of the velocity and acceleration
%all in 2D!!!
Abs_accel = sqrt(movmean((accelN.^2),30) + movmean((accelE.^2),1000) );
%+ (accelD.^2)
Abs_vel = sqrt (movmean((VelN.^2),30) + movmean((VelE.^2),1000) );
%+ (VelD.^2)
Abs_pos = sqrt ((smooth_north_position.^2) + (smooth_east_position.^2) );
%+ (smooth_north_position.^2)
z = 1;
i = 1;
% Merging angles with time 
%Angles_time has N E D R P Y T

Angles_time = [];
for z = 1 :length(NEDT)
    for a = 1 :length(Angles_window)
        if (Angles_window(a,4)- (NEDT (z,4))) < 0.002;
       Angles_time(a,:) = horzcat(NEDT(z,1:3), Angles_window(a,:));
        else
            
        end
    end
end

z=1;

for z = 1 :length(NEDT)    
    for  i = 1: length(Time_window)
    if roll_pitch_yaw_twindow(i,7) == NEDT(z,4);
        all_data (i,:) = horzcat(NEDT (z,1:3), roll_pitch_yaw_t(i,:));
    end
end
end 




%joining all data position and roll pitch yaw and equalising matrix sizes
all_data = [];
for z = 1 :length(NEDT)
    
    for a = 1 : length(roll_pitch_yaw_twindow)
        if ((NEDT (z,4))- roll_pitch_yaw_twindow(a,7)) < 0.002; 
        all_data (a,:) = horzcat(NEDT (z,1:3), roll_pitch_yaw_twindow(a,:));
        else
            
        end
    end
end
    

z = 1;
%all_data holds [N E D Rx Ry Px Py Yx Yy T]
% 
% universal_time = all_data(:,10);
% UT = universal_time;
% z = 1;
%join all data velocity and roll pitch yaw and equalise matrix size

Angles_time = [NEDT(:,1:3) Angles_window];



% joining all position data accelerations data
% for z = 1 :length(NEDT(1:end-2,:))    
%     for  i = 1: length(UT(1:end-2,:))
% 
%     
%     if NEDT_accels (i,4) == NEDT_vels(z,4);
%         all_data_and_accels (i,:) = horzcat(NEDT_vels (z,1:3), NEDT_accels(i,:));
%     end
% end
% end


% GRAPHS GRAPHS GRAPHS
% GRAPHS GRAPHS GRAPHS
% GRAPHS GRAPHS GRAPHS
% GRAPHS GRAPHS GRAPHS
% GRAPHS GRAPHS GRAPHS
z = 1;

%decimate_rate  = dr  
% You can reduce the number of data points by increasing this value.
dr = 10;

figure;
plot (Angles_time(:,7), Angles_time(:,6), Angles_time(:,7), Angles_time(:,4),Angles_time(:,7), Angles_time(:,5));
xlabel('Time (s)');
ylabel('Angle/degrees');
legend('Yaw', 'Roll', 'Pitch');


%quiver plot yaw

% 
% %quiver plot roll

figure;
comet (decimate(all_data (:,2),dr),decimate(all_data (:,1),dr));
xlabel('East Position(m)');
ylabel('North Position(m)');
% % Plot Yaw on comet plot
% hold on;
% quiver (decimate(all_data (:,2),dr),decimate(all_data (:,1),dr),decimate(all_data (:,8),dr),decimate(all_data (:,9),dr));
% legend('Yaw at position');
% xlabel('East Position(m)');
% ylabel('North Position(m)');
% hold off;

% plot(Time_window , Abs_pos, Time_window , Abs_vel, Time_window , Abs_accel)
% legend('Position', 'Velocity' , 'Acceleration');
% xlabel('Time(s)');
% ylabel('m,m/s,m/s2 ');


figure;
subplot (2,1,1)
plot(Time_window(1:end-2,1), Abs_accel)
legend('Acceleration');
xlabel('Time/s');
ylabel('m/s2 ');

subplot (2,1,2)
plot( Time_window(1:end-1,1), Abs_vel);
legend( 'Speed');
xlabel('Time/s');
ylabel('m/s');

figure;
subplot (2,1,1)
plot(Time_window(1:end-1,1), VelN)
legend('North Velocity');
xlabel('Time/s');
ylabel('m/s ');

subplot (2,1,2)
plot( Time_window(1:end-1,1), VelE);
legend( 'East Velocity');
xlabel('Time/s');
ylabel('m/s');


% 
%figure;
% plot3(all_data(:,2),all_data(:,1), all_data(:,3), position_east_gps, position_north_gps, data_alt_gps);
% legend('Fusion Position', 'GPS');
% xlabel('East (m)');
% ylabel('North (m)');
% zlabel('Altitude (m)');
% axis equal;


quiv_ds_rate = 50; % downsample rate
% 
% hold off;
% 

figure;
quiver (decimate(NEDT(1:end-1,2), quiv_ds_rate), ...
    decimate(NEDT(1:end-1,1), quiv_ds_rate), ...
    decimate(diff(NEDT(:,2)), quiv_ds_rate), ...
    decimate(diff(NEDT(:,1)), quiv_ds_rate));
legend('Velocity at position');
xlabel('East Position(m)');
ylabel('North Position(m)');

% figure;
% 
% plot(NEDT(1:end-2,2),(NEDT(1:end-2,1)));
% hold on;
% quiver (decimate(NEDT(1:end-2,2), quiv_ds_rate), ...
%     decimate(NEDT(1:end-2,1), quiv_ds_rate), ...
%     decimate(50*accelE(1:end,:), quiv_ds_rate), ...
%     decimate(50*accelN(1:end,:), quiv_ds_rate));
% legend('Acceleration at position');
% xlabel('East Position(m)');
% ylabel('North Position(m)');
% hold off;

% figure;
% % smooth_accels = movmean(all_data_and_accels,50);
% plot(all_data(:,2), all_data(:,1));
% hold on;
% quiver (decimate(NEDT(1:end-2,2),50),decimate(NEDT(1:end-2,1),50), decimate(accelE(1:end,:),50), decimate(accelN(1:end,:),50)); 
% 
% legend('Fusion Position','accel direction');
% xlabel('East (m)');
% ylabel('North (m)');
% 
% axis equal;
% hold off;


% figure;
% plot3(kal_x_stor(2, :), kal_x_stor(1, :), -kal_x_stor(3, :));
% legend('3D osition');
% xlabel('East Position(m)');
% ylabel('North Position(m)');
% zlabel('Height(m)');
% 
% quiv_ds_rate = 50;

% figure;
% plot3(kal_x_stor(2, :), kal_x_stor(1, :), -kal_x_stor(3, :)); 
% hold on;
% quiver3 (decimate(NEDT(1:end-2,2), quiv_ds_rate), ...
%     decimate(NEDT(1:end-2,1), quiv_ds_rate), ...
%     decimate(NEDT(1:end-2,3), quiv_ds_rate), ...
%     decimate(accelE(1:end,:), quiv_ds_rate), ...
%     decimate(accelN(1:end,:), quiv_ds_rate), ...
%     decimate(accelD(1:end,:), quiv_ds_rate));
% hold on;
% quiver3 (decimate(NEDT(1:end-1,2), quiv_ds_rate), ...
%     decimate(NEDT(1:end-1,1), quiv_ds_rate), ...
%     decimate(NEDT(1:end-1,3), quiv_ds_rate), ...
%     decimate(VelE, quiv_ds_rate), ...
%     decimate(VelN, quiv_ds_rate), ...
%     decimate(VelD, quiv_ds_rate)*-1);
% legend('path','acceleration','velocity')
% xlabel('east')
% ylabel('north')
% zlabel('altitude')
