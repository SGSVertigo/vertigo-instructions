% Yaw angle
Phi_radians = -atan2(2.*((quatdata(:,3).*quatdata(:,6))+(quatdata(:,4).*quatdata(:,5))),1 - 2.*(((quatdata(:,3).^2)+(quatdata(:,4).^2))));
Phi = (Phi_radians)*180./pi;
Yaw = Phi;
%roll angle
Theta_radians = asin (2.*(quatdata(:,4).*quatdata(:,6) -   quatdata(:,3).*quatdata(:,5)));
Theta = (Theta_radians).*180./pi;
Roll = Theta;
% Pitch angle
Psi_radians = atan2(2.*((quatdata(:,5).*quatdata(:,6))+(quatdata(:,3).*quatdata(:,4))),1 - 2.*(((quatdata(:,4).^2)+(quatdata(:,5).^2))));
Psi = (Psi_radians).*180./pi;
Pitch = Psi;
quiver_length = 3;
[rollx,rolly] = pol2cart(((Theta_radians)),quiver_length);
[pitchx,pitchy] = pol2cart(((Psi_radians+pi)),quiver_length);
[yawx,yawy] = pol2cart((Phi_radians),quiver_length);

%Cartesian vectors for roll, pitch and yaw with time
roll_pitch_yaw_t = [rollx rolly pitchx pitchy yawx yawy quatdata(:,1)];
Angles = [Roll Pitch Yaw quatdata(:,1)];



% u = velocity vector 
% v = roll vector (all_data(:,6:7) would be pitch data and all_data(:,8:9) would be yaw data)

% u = (diff(all_data (:,1:2)));
  u = [veleast(1:end-1) velnorth(1:end-1)];
  % NEDT_vels columns 1 and 2 hold North and East Velocities
v = [acceleast accelnorth];
% if working in 2d Create third element for a 3d vector as used by
% functions below
A = zeros(length(acceleast), 1);
uc = [u A];
vc = [v A];
z = 0;
 
    magu = zeros;
    magv = zeros;
% Find the magnitudes of the v and u vectors for use in the functions below
magu = sqrt((u(:,1).^2) + (u(:,2).^2));
magv = sqrt((v(:,1).^2) + (v(:,2).^2));  

for i = 1: length (u)
    
    X(i,1) = dot(u(i),v(i));
end

Y = magu.*magv;

for a = 1 :length(u)

ThetaInDegrees(a,1) = (acosd(X(a)./Y(a)));
end


figure
plot (Time(1:end-2), movmean(ThetaInDegrees',10));
title('Angle between velocity and acceleration vectors');
xlabel('Time/s');
ylabel('Angle between V and A');
xlim([Time_window1 Time_window2]);

figure;
plot(Time, Roll(Time_window1*100:Time_window2*100),Time, Pitch(Time_window1*100:Time_window2*100),Time, Yaw(Time_window1*100:Time_window2*100));

xlabel('Time/s');
ylabel('Angles ');
legend('Roll', 'Pitch', 'Yaw');
xlim([Time_window1 Time_window2]);




figure;
comet(east,north);
hold on


velnorth = (diff(north)./0.01);
veleast = (diff(east)./0.01);
accelnorth = (diff(velnorth)./0.01);
acceleast = (diff(veleast)./0.01);
DR = 20;
quiver (decimate(east(1:end-1,1),DR),decimate(north(1:end-1,1),DR), decimate(veleast(1:end,:),DR), decimate(velnorth(1:end,:),DR));

quiver (decimate(east(1:end-2,1),DR),decimate(north(1:end-2,1),DR), decimate(acceleast(1:end,:),DR), decimate(accelnorth(1:end,:),DR));
hold off;

legend('Velocity at position', 'Acceleration at Position');
xlabel('East Position(m)');
ylabel('North Position(m)');