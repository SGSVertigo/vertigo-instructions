function wbmf                               % window motion callback function to draw the rubber line
p1=getappdata(gcf,'p1');
lh=getappdata(gcf,'lh');
ptemp=get(gca,'CurrentPoint');
ptemp=ptemp(1,1:2);
set(lh,'XData',[p1(1),ptemp(1)],'YData',[p1(2),ptemp(2)]);
drawnow