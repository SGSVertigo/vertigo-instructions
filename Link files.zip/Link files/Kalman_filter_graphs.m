data_time = imudata(:, 1);
quat_data = quatdata(:, :);
euldata_window = euldata (:, :);
data_accel_down = (accel_ned(:, 3) - 1) * 9.81;
data_accel_north = (accel_ned(:, 1) ) * 9.81;
data_accel_east = -(accel_ned(:, 2) ) * 9.81;
data_gyro_ned = gyro_ned(:, :);
data_gyro = imudata(:, 6:8);

% Find the gps in UTM 
data_time_gps = gpsdata(:, 1);
[x,y,zone] = ll2utm(gpsdata(:,3),gpsdata(:,4));
%[x,y,zone] = ll2utm(lat,lon); % do the job!
%gpsdata(:,1) = (gpsdata(:,1) - gpsdata(1,1)) / 1000;
North_utm_position = (x(:,1)- x(1,1));
East_utm_position = (y(:,1)- y(1,1));
%plot (North_utm_position, East_utm_position);
position_north_gps =  North_utm_position ;
position_north_gps = position_north_gps - position_north_gps(1);
position_east_gps =  East_utm_position ;
position_east_gps = position_east_gps - position_east_gps(1);
data_alt_gps = gpsdata(:, 5);
data_alt_gps = data_alt_gps - data_alt_gps(1);

data_merged = sortrows([data_time 1*ones(length(data_time), 1) [1:length(data_time)]'; data_time_gps, 2*ones(length(data_time_gps), 1), [1:length(data_time_gps)]']);


% Euler: x+ = x + dx * dt
% Model: Fx + Gu (no inputs, random jerk)
% s+ = s + dt * v
% v+ = v + dt * a
Hg = [1 0 0 0]; % measure gps
Ha = [0 0 1 1]; % measure acc

% Initial state and covariance
x = [0 0 0 0]';
xn = [0 0 0 0]';
xe = [0 0 0 0]';
P = zeros(4, 4); P(3,3) = 1; P(4,4) = 1e0;

% Process noise
Q = diag([0 0 1e-4 1e-9]);
% Measurement noise
Ra = 1;
Rg = 0.01;

% Store Kalman
kal_x_stor = zeros(length(data_time), 4);
kal_xn_stor = zeros(length(data_time), 4);
kal_xe_stor = zeros(length(data_time), 4);
% Computation time
tc = data_time(1);

% Run Kalman
for i = 1:length(data_merged)
    % Find dt since samples can possibly be dropped
    dt = data_merged(i, 1) - tc;
    tc = data_merged(i, 1);
    
    % Find DT model
    F = [1 dt 0 0; 0 1 dt 0; 0 0 1 -1; 0 0 0 1];
    
    % Predict
    xp = F * x; % no inputs
    xpn = F * xn;
    xpe = F * xe;
    Pp = F * P * F' + Q;
    
    % Update for accel
    if data_merged(i, 2) == 1
        y = data_accel_down(data_merged(i, 3)) - Ha * x;
       
        yn = data_accel_north(data_merged(i, 3)) - Ha * xn; % North
        ye = data_accel_east(data_merged(i, 3)) - Ha * xe; % East

        S = Ha * P * Ha' + Ra;
        K = Pp * Ha' * 1/S;
        x = xp + K * y;
        
        xn = xpn + K * yn; % North
        xe = xpe + K * ye; % East

        P = (eye(4) - K * Ha) * Pp;
    elseif data_merged(i, 2) == 2
    % Update for GPS
        y = data_alt_gps(data_merged(i, 3)) - Hg * x;
        
        yn = position_north_gps(data_merged(i, 3)) - Hg * xn; % North
        ye = position_east_gps(data_merged(i, 3)) - Hg * xe; % East
             
        S = Hg * P * Hg' + Rg;
        K = Pp * Hg' * 1/S;
        x = xp + K * y;
        
        xn = xpn + K * yn; % North
        xe = xpe + K * ye; % East

        P = (eye(4) - K * Hg) * Pp;
    end
    
    % Store
    kal_x_stor(i, :) = x;
    kal_xn_stor(i, :) = xn;
    kal_xe_stor(i, :) = xe;
end



prompt = 'What time do you wish to start analysis from? ';
window_start = input(prompt);
prompt = 'What time do you wish to end the analysis? ';
window_end = input(prompt);

%Total time samples
total_time = [ data_time ; data_time_gps];
%sort in time chronological order
stotal_time = sort(total_time);

all_data = [];
% Extract the bit of data we want to look at
tstartidx = find(stotal_time(:,1) > window_start, 1);
tendidx = find(stotal_time(:,1) > window_end, 1);
Time_window = stotal_time(tstartidx:tendidx,1);
%smoothing the data
smooth_down_position = smooth(kal_x_stor(tstartidx:tendidx,1));
smooth_east_position = smooth(kal_xe_stor(tstartidx:tendidx,1));
smooth_north_position = smooth (kal_xn_stor(tstartidx:tendidx,1));
down_accel_elements = smooth (kal_x_stor(tstartidx:tendidx,1));
north_accel_elements = smooth(kal_xn_stor(tstartidx:tendidx,3));
east_accel_elements = smooth(kal_xe_stor(tstartidx:tendidx,3));
north_vel_elements = smooth (kal_xn_stor(tstartidx:tendidx,2));
east_vel_elements = smooth (kal_xe_stor(tstartidx:tendidx,2));
down_vel_elements = smooth (kal_x_stor(tstartidx:tendidx,2));
positionsE = smooth_east_position(:,:);
positionsN = smooth_north_position(:,:);
positionsD = smooth_down_position(:,:);

quat_data = quatdata(tstartidx:tendidx, :);
euldata_window = euldata (tstartidx:tendidx, :);

NEDT = [smooth_north_position smooth_east_position smooth_down_position Time_window];
NEDT_vels = [north_vel_elements east_vel_elements down_vel_elements Time_window];
NEDT_accels = [north_accel_elements east_accel_elements down_accel_elements Time_window];
% NEW CODE FOR ANGLES HERE
data_accel = [data_accel_north(tstartidx:tendidx, :) data_accel_east(tstartidx:tendidx, :) data_accel_down(tstartidx:tendidx, :) Time_window];


Phi_radians = atan2(2.*((quat_data(:,3).*quat_data(:,6))+(quat_data(:,4).*quat_data(:,5))),1 - 2.*(((quat_data(:,3).^2)+(quat_data(:,4).^2))));
Phi = (Phi_radians)*180./pi;
Theta_radians = asin (2.*(quat_data(:,4).*quat_data(:,6) -   quat_data(:,3).*quat_data(:,5)));
Theta = (Theta_radians).*180./pi;
Psi_radians = atan2(2.*((quat_data(:,5).*quat_data(:,6))+(quat_data(:,3).*quat_data(:,4))),1 - 2.*(((quat_data(:,4).^2)+(quat_data(:,5).^2))));
Psi = (Psi_radians).*180./pi;



quiver_length = 3;
[rollx,rolly] = pol2cart(((Theta_radians)),quiver_length);
[pitchx,pitchy] = pol2cart(((Psi_radians+pi)),quiver_length);
[yawx,yawy] = pol2cart((Phi_radians),quiver_length);

%Cartesian vectors for roll, pitch and yaw with time
roll_pitch_yaw_t = [rollx rolly pitchx pitchy yawx yawy Time_window(:,1)];
Abs_accel = sqrt ((north_accel_elements.^2) + (east_accel_elements.^2) + (down_accel_elements.^2));
Abs_vel = sqrt ((north_vel_elements.^2) + (east_vel_elements.^2) + (down_vel_elements.^2));
Abs_pos = sqrt ((positionsE.^2) + (positionsN.^2) + (positionsD.^2));


%joining all data position and equalising matrix sizes
for z = 1 :length(NEDT)    
    for  i = 1: length(Time_window)

    
    if roll_pitch_yaw_t(i,7) == NEDT(z,4);
        all_data (i,:) = horzcat(NEDT (z,1:3), roll_pitch_yaw_t(i,:));
    end
end
end
z = 1;
%all_data holds [N E D Rx Ry Px Py Yx Yy T]

%join all data velocity and roll pitch yaw and equalise matrix size
for z = 1 :length(NEDT_vels)    
    for  i = 1: length(Time_window)

    
    if roll_pitch_yaw_t(i,7) == NEDT_vels(z,4);
        all_data_vel (i,:) = horzcat(NEDT_vels (z,1:3), roll_pitch_yaw_t(i,:));
    end
end
end


% joining all position data and imudata data
for z = 1 :length(NEDT)    
    for  i = 1: length(Time_window)

    
    if data_accel (i,4) == NEDT_vels(z,4);
        all_data_and_accels (i,:) = horzcat(NEDT_vels (z,1:3), data_accel(i,:));
    end
end
end
all_data_and_accels = all_data_and_accels(1:length(all_data),:);
all_data_vel = all_data_vel(1:length(all_data),:);

% GRAPHS GRAPHS GRAPHS
% GRAPHS GRAPHS GRAPHS
% GRAPHS GRAPHS GRAPHS
% GRAPHS GRAPHS GRAPHS
% GRAPHS GRAPHS GRAPHS
z = 1;

%decimate_rate  = dr  
% You can reduce the number of data points by increasing this value.
dr = 40;

figure;
plot (Time_window(:,1), Phi, Time_window(:,1), Theta, Time_window(:,1), Psi);
xlabel('Time (s)');
ylabel('Angle/degrees');
legend('Yaw', 'Roll', 'Pitch');

figure;
subplot (3,1,1)

plot(quat_data(:,1), Theta);
xlabel('Time (s)');
ylabel('Angle/ deg');
legend('Roll NED');

subplot (3,1,2)

plot(quat_data(:,1), Psi);
xlabel('Time (s)');
ylabel('Angle/ deg');
legend('Pitch NED');

subplot (3,1,3)

plot(quat_data(:,1), Phi);
xlabel('Time (s)');
ylabel('Angle/ deg');
legend('Yaw NED');


%quiver plot yaw

% 
% %quiver plot roll

figure;
subplot (3,1,1);
plot (decimate(all_data (:,2),dr),decimate(all_data (:,3),dr));
xlabel('East Position(m)');
ylabel('Down Position(m)');
hold on;
quiver (decimate(all_data (:,2),dr),decimate(all_data (:,3),dr),decimate(all_data (:,4),dr),decimate(all_data (:,5),dr));
legend('Roll at position');
xlabel('East Position(m)');
ylabel('Down Position(m)');

%quiver plot pitch
subplot (3,1,2);
plot(decimate(all_data (:,2),dr),decimate(all_data (:,3),dr));
xlabel('North Position(m)');
ylabel('Down Position(m)');
hold on;
quiver (decimate(all_data (:,2),dr),decimate(all_data (:,3),dr),decimate(all_data (:,6),dr),decimate(all_data (:,7),dr));
legend('Pitch at position');
xlabel('North Position(m)');
ylabel('Down Position(m)');

hold off;
subplot (3,1,3);
comet (decimate(all_data (:,2),dr),decimate(all_data (:,1),dr));
xlabel('East Position(m)');
ylabel('North Position(m)');
% Plot Yaw on comet plot
hold on;
quiver (decimate(all_data (:,2),dr),decimate(all_data (:,1),dr),decimate(all_data (:,8),dr),decimate(all_data (:,9),dr));
legend('Yaw at position');
xlabel('East Position(m)');
ylabel('North Position(m)');
hold off;

% plot(Time_window , Abs_pos, Time_window , Abs_vel, Time_window , Abs_accel)
% legend('Position', 'Velocity' , 'Acceleration');
% xlabel('Time(s)');
% ylabel('m,m/s,m/s2 ');


figure;
subplot (2,2,1)
plot(Time_window, Abs_pos,Time_window, Abs_vel,Time_window, Abs_accel)
legend('Position', 'Velocity' , 'Acceleration');
xlabel('Time/s');
ylabel('m,m/s,m/s2 ');

subplot (2,2,2)
plot( Time_window, Abs_accel);
legend( 'Acceleration magnitude');
xlabel('Time/s');
ylabel('m/s2 ');

subplot (2,2,3)
plot(decimate(all_data (:,2),dr),decimate(all_data (:,1),dr));
xlabel('East Position(m)');
ylabel('North Position(m)');



subplot(2,2,4)
plot (Time_window, Phi, Time_window, Theta, Time_window, Psi);
xlabel('Time (s)');
ylabel('Roll, Pitch, Yaw/rad');
legend('Yaw', 'Roll', 'Pitch');
% 
figure;
plot3(all_data(:,2),all_data(:,1), all_data(:,3), position_east_gps, position_north_gps, data_alt_gps);
legend('Fusion Position', 'GPS');
xlabel('East (m)');
ylabel('North (m)');
zlabel('Altitude (m)');
axis equal;


quiv_ds_rate = 60; % downsample rate

hold off;







figure;
quiver (decimate(NEDT(1:end-1,2), quiv_ds_rate), ...
    decimate(NEDT(1:end-1,1), quiv_ds_rate), ...
    decimate(diff(NEDT(:,2)), quiv_ds_rate), ...
    decimate(diff(NEDT(:,1)), quiv_ds_rate));
legend('Velocity at position');
xlabel('East Position(m)');
ylabel('North Position(m)');

figure;
accelE = movmean(diff(diff(NEDT(:,2))),20);
accelN = movmean(diff(diff(NEDT(:,1))),20);
quiver (decimate(NEDT(1:end-2,2), quiv_ds_rate), ...
    decimate(NEDT(1:end-2,1), quiv_ds_rate), ...
    decimate(accelE(1:end,:), quiv_ds_rate), ...
    decimate(accelN(1:end,:), quiv_ds_rate));
legend('Acceleration at position');
xlabel('East Position(m)');
ylabel('North Position(m)');


figure;
accelE = diff(diff(NEDT(:,2)));
accelN = diff(diff(NEDT(:,1)));
smooth_accels = movmean(all_data_and_accels,50);
plot(all_data(:,2), all_data(:,1));
hold on;
quiver (all_data(100:end-2,2),all_data(100:end-2,1), accelE(100:end,:),accelN(100:end,:)); 

legend('Fusion Position','accel direction');
xlabel('East (m)');
ylabel('North (m)');

axis equal;
hold off;







