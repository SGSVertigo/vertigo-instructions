plot(fit1, NEDT(:,1), NEDT(:,4));
% plot(fit1,xdata,ydata)