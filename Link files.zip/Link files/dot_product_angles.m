
% u = velocity vector 
% v = roll vector (all_data(:,6:7) would be pitch data and all_data(:,8:9) would be yaw data)

% u = (diff(all_data (:,1:2)));
  u = NEDT_vels(1:end,1:2);
  % NEDT_vels columns 1 and 2 hold North and East Velocities
v = all_data(1:end-1,4:5);
% if working in 2d Create third element for a 3d vector as used by
% functions below
A = zeros((length(UT)-1), 1);
uc = [u A];
vc = [v A];
z = 0;
 
    magu = zeros;
    magv = zeros;
% Find the magnitudes of the v and u vectors for use in the functions below
magu = sqrt((u(:,1).^2) + (u(:,2).^2));
magv = sqrt((v(:,1).^2) + (v(:,2).^2));  

CP = (cross(uc,vc,2));
CPmag = sqrt(CP(:,3).^2);
ThetaInDegrees = [];
% Calculate the angles between the vectors u and v
for a = 1 :length(uc)

ThetaInDegrees(a) = atan2d(CPmag(a,1),dot(uc(a,1),vc(a,1),2));
end
% Plot the results taking a moving mean over 200 samples

figure
plot (all_data(1:end-1,10), movmean(ThetaInDegrees,200));
title('Angle between velocity and Pitch rotation');
xlabel('Time/s');
ylabel('Angle between velocity and Pitch / degrees ');



