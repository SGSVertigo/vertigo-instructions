function qo = quatconj( qi ) 

qo = [ qi(:,1)  -qi(:,2:4) ];
