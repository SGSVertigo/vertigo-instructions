% Jon Sowman 2017
% Jamie Costello
% jon+vertigo@jonsowman.com
%
% This file is part of the Vertigo project
%
% Rotate the IMU data into the NED frame using the AHRS data

accel_ned = zeros(length(imudata), 3);
gyro_ned  = zeros(length(imudata), 3);

for i = 1:length(imudata)
    quat_int = interp1(quatdata(:,1), quatdata(:, 3:6), imudata(i,1));
    a = [0 imudata(i, 3:5)];
    g = [0 imudata(i, 6:8)];
    aa = quatmultiply(quatmultiply(quat_int, a), quatconj(quat_int));
    accel_ned(i, :) = aa(2:4);
    gg= quatmultiply(quatmultiply(quat_int, g), quatconj(quat_int));
    gyro_ned(i, :) = gg(2:4);
end

% This section uses the trapezium ruke to calculate the 
% distance travelled by Vertigo in the North, East and Down directions.
figure;
subplot (2,1,1);
time = [diff(imudata(:,1)); 10];
North = cumtrapz(imudata(:,1), 0.00000981 * accel_ned(:,1));
North = cumtrapz(imudata(:,1), North);
East = cumtrapz(imudata(:,1),  0.00000981 * accel_ned(:,2));
East = cumtrapz(imudata(:,1), East);
Down = cumtrapz(imudata(:,1), 0.00000981 * (accel_ned(:,3) - 0.981));
Down = cumtrapz(imudata(:,1), Down);

%plot positions with drift
plot (imudata(:,1), North, imudata(:,1), East,imudata(:,1), Down);
xlabel('Time (ms)');
ylabel('NED Position(m) ')
legend('N', 'E', 'D');

%find Polyfit Coefficient Numbers for each of North, East Down (PCN, PCE,
%PCD) with polynomial of order 10.  10 may be too large, it can be
%modified.
% Create polyfit Values (PVN, PVE, PVD) for all times (imudata (:,1).
% Column 1 in imudata is time.

pcn = polyfit(imudata(:,1),North,10)
pvn = polyval(pcn,imudata(:,1));

subplot (2,1,2);
plot (imudata(:,1), North - pvn);
xlabel('Time (ms)');
ylabel('North Position(m)')

%choose times to look at in detail - between 500 and 2000 milliseconds shown here

Corrected_North = North (500:2000)- pvn(500:2000);
Time = imudata(500:2000)- imudata(500);

figure;
plot ( Time, Corrected_North);
%Time, Corrected_North, Time, Corrected_East,
%Not bad.... but there's more to do in vertigo_wheel_analysisII
xlabel('Time (ms)');
ylabel('Corrected North Position(m) ')


