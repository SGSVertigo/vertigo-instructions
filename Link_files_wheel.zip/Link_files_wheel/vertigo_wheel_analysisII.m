plot (Time, Corrected_North);
xlabel('Time (ms)');
ylabel('Corrected North Position(m)');
% The first time you run this script you will get an error.  It will read as follows:
%       Undefined variable "cursor_info" or class "cursor_info.Position".
% 
%       Error in vertigo_wheel_analysisII (line 13)
%       A = [cursor_info.Position];
% 
% This is because you need to review with the cursor tool the first plotted graph before moving forward. 


% once plotted pick the cursor data tool on the figure screen.  Mark a
% point at the top of the first blue peak.  Then right click, add new
% cursor data point and point out the second blue peak.  
% This is easier to do if the screen is maximized.  
% Do this for all of the blue peaks- IN ORDER!

%Finally, right click and export data to workspace
%Create a matrix for this new data call it A

A = [cursor_info.Position];


%All of the times are X coordintaes and they are in the odd positions in the columns so:
%My new matrix T holds all of the time values 
T = A([1 3 5 7 9 11 13 15 17]);

%Similarly my North positions are all in even slots so:
N = A ([2 4 6 8 10 12 14 16 18])


% Find polyfit coefficients for N

pcN = polyfit(T,N,5);
pvN = polyval(pcN,Time);

figure;
plot (Time, pvN);
xlabel('Time (ms)');
ylabel('curve fit (m)');
% and finally we plot the most corrected graph - note pvN' that means I have
% swapped Columns into rows- that's all.
figure;
plot (Time, (Corrected_North - pvN'));
xlabel('Time (ms)');
ylabel('Final Corrected North Position(m)');


% you need to go through this process for the East direction.
% Remember you can adjust the power of the polyfit polynomial curve to get a better
% fit.





