function turning_points = find_turning_points(uncorrected_x, time)

[local_maxima_x, locsmax_x] = findpeaks(uncorrected_x,time);
[local_minima_flipped_x, locsmin_x] = findpeaks(-uncorrected_x,time);

local_minima_x = -local_minima_flipped_x; 

max_points_x = [locsmax_x local_maxima_x];
min_points_x = [locsmin_x local_minima_x];

turning_points_untransposed = sortrows([max_points_x ;min_points_x]);
turning_points = reshape(turning_points_untransposed.',1,[]);

end

