function correctedX = remove_drift(uncorrectedX, Time)

% rmsN = rms(Corrected_North);
% figure;
% plot (Time, uncorrectedX);
% xlabel('Time(s)');
% ylabel('Corrected North Position(m)');



A = find_turning_points(uncorrectedX,Time);

% T = A([1 3 5]);

odds1 = 1:2:(size(A,2));
odds2 = 1:2:((size(A,2)./2)-1);
T = A([odds1]);

for k = 1: (size(T,2)-1)
    Tav(1,k) = ((T(1,k)+ T(1,k+1)))./2;
end
Tav2 = Tav([odds2]);


evens = 2:2:(size(A,2));
evens2 = 2:2:((size(A,2)./2)-1);
N = A([evens]);

for k = 1: (size(N,2)-1)
    Dav(1,k) = ((N(1,k)+ N(1,k+1)))./2;
end

Dav2 = Dav([odds2]);
% difference = diff(p_t);
% 
% drift = difference([odds2]);



pcX = polyfit(Tav2,Dav2,4);

pvX = polyval(pcX,Time);
% 
% if exist('position', 'var')
%     plot (Time, pvX);
%     xlabel('Time (s)');
%     ylabel('curve fit (m)');

    


%     '+position+'
correctedX = (uncorrectedX) - pvX;
% figure;
%     plot (Time,(uncorrectedX) - pvX);


end




