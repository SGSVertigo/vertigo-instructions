
addpath(genpath('vtg_utils'));

% Get raw data
[csvfile, csvpath] = uigetfile('*.csv');
csvdata = csvread([csvpath csvfile]);

% Fix timer rollover
rollover = 2^32/1e4; % todo: import from config
all_times = csvdata(:,1);
delta_times = find(diff(all_times) < 0);
for i = 1:length(delta_times)
    all_times(delta_times(i)+1:end) = all_times(delta_times(i)+1:end) ...
        + rollover;
end
csvdata(:,1) = all_times;

% Split into GPS and IMU data
gpsidx = find(csvdata(:,2) == 1);
imuidx = find(csvdata(:,2) == 2);
quatidx = find(csvdata(:,2) == 3);
gpsdata = csvdata(gpsidx, :);
imudata = csvdata(imuidx, :);
quatdata = csvdata(quatidx, :);

% Adjust all times
gpsdata(:,1) = (gpsdata(:,1) - gpsdata(1,1)) / 1000;
imudata(:,1) = (imudata(:,1) - imudata(1,1)) / 1000;
quatdata(:,1) = (quatdata(:,1) - quatdata(1,1)) / 1000;

% Do quaternion->Euler conversion
euldata = zeros(length(quatdata), 3);
for i = 1:length(quatdata)
    euldata(i,:) = vtg_quat2eul(quatdata(i,3:6));
end

t = imudata(:,1); % Time Variable
accel_ned = zeros(length(imudata), 3);
gyro_ned  = zeros(length(imudata), 3);

% Create NED frame data by using pqp'
for i = 1:length(imudata)
    quat_int = interp1(quatdata(:,1), quatdata(:, 3:6), imudata(i,1));
    a = [0 imudata(i, 3:5)];
    g = [0 imudata(i, 6:8)];
    aa = quatmultiply(quatmultiply(quat_int, a), quatconj(quat_int));
    accel_ned(i, :) = aa(2:4);
    gg= quatmultiply(quatmultiply(quat_int, g), quatconj(quat_int));
    gyro_ned(i, :) = gg(2:4);
end











figure;
plot(imudata(:,1), accel_ned);
xlabel('Time (s)');
ylabel('NED accel (g)');
legend('N', 'E', 'D');

prompt = 'What time do you wish to start analysis from? ';
Time_window1 = input(prompt);
prompt = 'What time do you wish to end the analysis? ';
Time_window2 = input(prompt);

% accel_ned = zeros(length(imudata), 3);
% gyro_ned  = zeros(length(imudata), 3);



accel_ned(end,:) = accel_ned(end-1,:);


time = [diff(imudata(:,1)); 10];
North = cumtrapz(imudata(100*Time_window1:100*Time_window2,1), 9.81 * accel_ned(100*Time_window1:100*Time_window2,1));
North = cumtrapz(imudata(100*Time_window1:100*Time_window2,1), North);
East = cumtrapz(imudata(100*Time_window1:100*Time_window2,1),  9.81 * accel_ned(100*Time_window1:100*Time_window2,2));
East = cumtrapz(imudata(100*Time_window1:100*Time_window2,1), East);
Down = cumtrapz(imudata(100*Time_window1:100*Time_window2,1), (9.81 * (accel_ned(100*Time_window1:100*Time_window2,3) - 1)));
Down = cumtrapz(imudata(100*Time_window1:100*Time_window2,1), Down);
%plot raw positions



%find polyfit coefficient Values for each of North, East Down (PCN, PCE,
%PCD) with polynomial of order 10- which may well be excessive.
% Create a polyfit values (PVN, PVE, PVD) for all times (imudata (:,1) -all times from
% column 1)
pcn = polyfit(imudata(100*Time_window1:100*Time_window2,1),North,4);
pvn = polyval(pcn,imudata(100*Time_window1:100*Time_window2,1));
pce = polyfit(imudata(100*Time_window1:100*Time_window2,1),East,4);
pve = polyval(pce,imudata(100*Time_window1:100*Time_window2,1));
pcd = polyfit(imudata(100*Time_window1:100*Time_window2,1),Down(:),4);
pvd = polyval(pcd,imudata(100*Time_window1:100*Time_window2,1));


Time = imudata(100*Time_window1:100*Time_window2,1);
down = remove_drift(Down - pvd, Time);


figure;
subplot(2,1,1);
 


subplot(2,1,1);
    plot (Time, down)
    xlabel('Time (s)');
    ylabel('Down Position(m)');
    xlim([Time_window1 Time_window2]);
  
    subplot(2,1,2);
    plot (Time(1:end),movmean(accel_ned(100*Time_window1:100*Time_window2),3,20));
  xlabel('Time (s)');
    ylabel('Down Acceleration / m/s2');
     xlim([Time_window1 Time_window2]);
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%555
     


     




% Calculating Angles in NED frame
% Yaw angle
Phi_radians = -atan2(2.*((quatdata(:,3).*quatdata(:,6))+(quatdata(:,4).*quatdata(:,5))),1 - 2.*(((quatdata(:,3).^2)+(quatdata(:,4).^2))));
Phi = (Phi_radians)*180./pi;
Yaw = Phi;
%roll angle
Theta_radians = asin (2.*(quatdata(:,4).*quatdata(:,6) -   quatdata(:,3).*quatdata(:,5)));
Theta = (Theta_radians).*180./pi;
Roll = Theta;
% Pitch angle
Psi_radians = atan2(2.*((quatdata(:,5).*quatdata(:,6))+(quatdata(:,3).*quatdata(:,4))),1 - 2.*(((quatdata(:,4).^2)+(quatdata(:,5).^2))));
Psi = (Psi_radians).*180./pi;
Pitch = Psi;
quiver_length = 3;
% Producing Pitch, roll, yaw vector arrows 
[rollx,rolly] = pol2cart(((Theta_radians)),quiver_length);
[pitchx,pitchy] = pol2cart(((Psi_radians+pi)),quiver_length);
[yawx,yawy] = pol2cart((Phi_radians),quiver_length);

roll_pitch_yaw_t = [rollx rolly pitchx pitchy yawx yawy quatdata(:,1)];
roll_pitch_yaw_twindow = roll_pitch_yaw_t (100*Time_window1:100*Time_window2,:);
Angles = [Roll Pitch Yaw quatdata(:,1)];
Angles = Angles(100*Time_window1:100*Time_window2,:);

all_data = [down roll_pitch_yaw_twindow];

% 
% Creating borad angle matrix

[rollb,rollb2] = pol2cart((6.26.*(euldata(:,1))./360),quiver_length);
[pitchb,pitchb2] = pol2cart((6.26.*(euldata(:,2))./360),quiver_length);
[yawb,yawb2] = pol2cart((6.26.*(euldata(:,3))./360),quiver_length);

euldata = euldata(100*Time_window1:100*Time_window2,:);
roll_pitch_yaw_tb = [rollb rollb2 pitchb pitchb2 yawb yawb2 quatdata(:,1)];
roll_pitch_yaw_twindowb = roll_pitch_yaw_tb (100*Time_window1:100*Time_window2,:);






figure;
% Ploting spinning rate in NED and world frame
% Vertigo frame Gyro

subplot(2,1,1);
title('Rotation in Vertigo frame of reference');
plot(imudata(100*Time_window1:100*Time_window2,1), imudata(100*Time_window1:100*Time_window2, 6:8));
xlabel('Time (s)');
ylabel('Raw gyro (deg/s)');
legend('x', 'y', 'z');
  xlim([Time_window1 Time_window2]);

% Angles in Vertigo Frame
subplot(2,1,2);
plot(quatdata(100*Time_window1:100*Time_window2,1), euldata(:,:));
xlabel('Time (s)');
ylabel('Orientation (deg)');
legend('roll', 'pitch', 'yaw');
 xlim([Time_window1 Time_window2]);
% 
% Gyro NED frame
figure;
subplot(2,1,1);
title('Rotations around world frame of reference NED');
plot(imudata(100*Time_window1:100*Time_window2,1), gyro_ned(100*Time_window1:100*Time_window2,:));
xlabel('Time (s)');
ylabel('NED gyro (deg/s)');
legend('N', 'E', 'D');
 xlim([Time_window1 Time_window2]);

% Angles NED Frame
subplot(2,1,2);
plot(Angles(:,4),Angles(:,1),Angles(:,4),Angles(:,2),Angles(:,4),Angles(:,3));
xlabel('Time (s)');
ylabel('Roll, Pitch, Yaw / Degrees');
legend('R', 'P', 'Y');
xlim([Time_window1 Time_window2]);



%      Quiver Plots
figure;
dr = 1;



% down - yaw
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(all_data (:,6),dr),decimate(all_data (:,7),dr));
legend('Yaw at position');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);
figure;
% down pitch
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(all_data (:,4),dr),decimate(all_data (:,5),dr));
legend('Pitch at position');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);

figure;
% down roll
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(all_data (:,2),dr),decimate(all_data (:,3),dr));
legend('Roll at position');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);


figure;

subplot(2,2,1)
plot(Angles(:,4),Angles(:,1),Angles(:,4),Angles(:,2),Angles(:,4),Angles(:,3));
xlabel('Time (s)');
ylabel('Roll, Pitch, Yaw / Degrees');
legend('R', 'P', 'Y');
xlim([Time_window1 Time_window2]);


subplot(2,2,2)
% down - yaw
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(all_data (:,6),dr),decimate(all_data (:,7),dr));
legend('Yaw at position');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);



subplot(2,2,3)
% down pitch
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(all_data (:,4),dr),decimate(all_data (:,5),dr));
legend('Pitch at position');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);

subplot(2,2,4)
% down roll
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(all_data (:,2),dr),decimate(all_data (:,3),dr));
legend('Roll at position');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);



figure;

subplot(2,2,1)
plot(quatdata(100*Time_window1:100*Time_window2,1),euldata(:,1),quatdata(100*Time_window1:100*Time_window2,1),euldata(:,2),quatdata(100*Time_window1:100*Time_window2,1),euldata(:,3));
xlabel('Time (s)');
ylabel('x-anlge, y-angle, z-angle / Degrees');
legend('X', 'Y', 'Z');
xlim([Time_window1 Time_window2]);


subplot(2,2,2)
% down - yaw
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(roll_pitch_yaw_twindowb(:,1),dr),decimate(roll_pitch_yaw_twindowb (:,2),dr));
legend('Board X at position');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);



subplot(2,2,3)
% down pitch
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(roll_pitch_yaw_twindowb(:,3),dr),decimate(roll_pitch_yaw_twindowb (:,4),dr));
legend('Board Y position');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);

subplot(2,2,4)
% down roll
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(roll_pitch_yaw_twindowb(:,5),dr),decimate(roll_pitch_yaw_twindowb (:,6),dr));
legend('Board Z position');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%PERTINENT TO ROLL
figure
% Angles in Vertigo Frame
subplot(2,2,1);
plot(quatdata(100*Time_window1:100*Time_window2,1), euldata(:,1));
xlabel('Time (s)');
ylabel('Roll about X axis');
xlim([Time_window1 Time_window2]);


subplot(2,2,2);
plot(Angles(:,4),Angles(:,1));
xlabel('Time (s)');
ylabel('Roll in world frame/ Degrees');
xlim([Time_window1 Time_window2]);

subplot(2,2,3)
% down roll
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(roll_pitch_yaw_twindowb(:,1),dr),decimate(roll_pitch_yaw_twindowb (:,2),dr));
legend('Roll about X axis');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);


subplot(2,2,4)
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(all_data (:,2),dr),decimate(all_data (:,3),dr));
legend('Roll in world frame');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);


%PERTINENT TO Pitch
figure
% Angles in Vertigo Frame
subplot(2,2,1);
plot(quatdata(100*Time_window1:100*Time_window2,1), euldata(:,2));
xlabel('Time (s)');
ylabel('Pitch about Y axis');
xlim([Time_window1 Time_window2]);


subplot(2,2,2);
plot(Angles(:,4),Angles(:,2));
xlabel('Time (s)');
ylabel('Pitch in world frame/ Degrees');
xlim([Time_window1 Time_window2]);

subplot(2,2,3)
% down roll
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(roll_pitch_yaw_twindowb(:,3),dr),decimate(roll_pitch_yaw_twindowb (:,4),dr));
legend('Pitch about Y axis');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);


subplot(2,2,4)
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(all_data (:,4),dr),decimate(all_data (:,5),dr));
legend('Pitch in world frame');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);

%PERTINENT TO Yaw
figure
% Angles in Vertigo Frame
subplot(2,2,1);
plot(quatdata(100*Time_window1:100*Time_window2,1), euldata(:,3));
xlabel('Time (s)');
ylabel('Yaw about Z axis');
xlim([Time_window1 Time_window2]);


subplot(2,2,2);
plot(Angles(:,4),Angles(:,3));
xlabel('Time (s)');
ylabel('Pitch in world frame/ Degrees');
xlim([Time_window1 Time_window2]);

subplot(2,2,3)
% down roll
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(roll_pitch_yaw_twindowb(:,5),dr),decimate(roll_pitch_yaw_twindowb (:,6),dr));
legend('Yaw about Z axis');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);


subplot(2,2,4)
plot(decimate(all_data (:,8),dr),decimate(all_data (:,1),dr));
% Pitch at east position
% xlabel('Time');
% ylabel('East Position(m)');
hold on;
quiver (decimate(all_data (:,8),dr),decimate(all_data (:,1),dr),decimate(all_data (:,6),dr),decimate(all_data (:,7),dr));
legend('Yaw in world frame');
xlabel('Time/s');
ylabel('Down/m');
xlim([Time_window1 Time_window2]);